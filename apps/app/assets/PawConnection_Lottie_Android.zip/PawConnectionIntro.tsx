import React from 'react';
import { StyleSheet, View } from 'react-native';
import LottieView from 'lottie-react-native';

type Props = {
  onFinish?: () => void;
};

/** Place this file and paw-connection-intro.lottie.json in the same directory. */
export function PawConnectionIntro({ onFinish }: Props) {
  return (
    <View style={styles.container}>
      <LottieView
        source={require('./paw-connection-intro.lottie.json')}
        autoPlay
        loop={false}
        resizeMode="contain"
        onAnimationFinish={(cancelled) => {
          if (!cancelled) onFinish?.();
        }}
        style={styles.animation}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFAF6',
  },
  animation: {
    width: '100%',
    aspectRatio: 1,
  },
});
