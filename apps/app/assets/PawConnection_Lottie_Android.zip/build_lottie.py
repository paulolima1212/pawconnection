"""Create Paw Connection's vector intro from the supplied SVG artwork."""
import ast
import json
import re
from pathlib import Path
from xml.etree import ElementTree as ET

SVG=Path('upload/paw-connection-logo.svg')
OUT=Path('paw-connection-intro.lottie.json')
FPS=30
SCALE=600/190
ROOT=ET.parse(SVG).getroot()
PATHS={p.attrib['id']:p.attrib for p in ROOT[0]}
LOGO_X=60
LOGO_Y=360-(600*120/190)/2
PAW_ANCHOR=[81.5*SCALE,45.8*SCALE,0]
PAW_FINAL=[LOGO_X+PAW_ANCHOR[0],LOGO_Y+PAW_ANCHOR[1],0]

def const(value): return {'a':0,'k':value}
def keys(items):
    # The final keyframe deliberately omits s/e, as in a Bodymovin export.
    out=[]
    for (t,v),(next_t,next_v) in zip(items,items[1:]):
        out.append({'t':t,'s':v,'e':next_v,
                    'i':{'x':[.67],'y':[1]},'o':{'x':[.33],'y':[0]}})
    out.append({'t':items[-1][0]})
    return {'a':1,'k':out}
def transform(position,anchor=None,scale=None,rotation=None,opacity=None):
    return {'a':const(anchor or [0,0,0]),'p':position,'s':scale or const([100,100,100]),
            'r':rotation or const(0),'o':opacity or const(100)}

def rgb(hex_value):
    return [int(hex_value[i:i+2],16)/255 for i in (1,3,5)]+[1]

def parse_path(d):
    tokens=re.findall(r'[MCLHVZ]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?',d)
    i=0; cmd=None; current=[0.,0.]; start=None; points=[]; incoming=[]; outgoing=[]; result=[]
    def pair():
        nonlocal i
        a=float(tokens[i]); b=float(tokens[i+1]); i+=2
        return [a*SCALE,b*SCALE]
    def finish(closed):
        nonlocal points,incoming,outgoing,start
        if not points: return
        if closed and len(points)>1 and points[-1]==points[0]:
            points.pop(); incoming[0]=incoming.pop(); outgoing.pop()
        result.append({'c':closed,'v':points,'i':incoming,'o':outgoing})
        points=[]; incoming=[]; outgoing=[]; start=None
    def add_line(p):
        nonlocal current
        if not points:
            points.append(p); incoming.append([0,0]); outgoing.append([0,0])
        else:
            points.append(p); incoming.append([0,0]); outgoing.append([0,0])
        current=p
    def cubic(c1,c2,p):
        nonlocal current
        if not points: add_line(current)
        outgoing[-1]=[c1[0]-current[0],c1[1]-current[1]]
        points.append(p); incoming.append([c2[0]-p[0],c2[1]-p[1]]); outgoing.append([0,0]); current=p
    while i<len(tokens):
        if tokens[i].isalpha():
            cmd=tokens[i]; i+=1
            if cmd=='Z':
                old_start=start
                finish(True); current=old_start or current
                continue
        if cmd=='M':
            p=pair(); finish(False); start=p; add_line(p); cmd='L'
        elif cmd=='L': add_line(pair())
        elif cmd=='H':
            x=float(tokens[i])*SCALE; i+=1; add_line([x,current[1]])
        elif cmd=='V':
            y=float(tokens[i])*SCALE; i+=1; add_line([current[0],y])
        elif cmd=='C': cubic(pair(),pair(),pair())
        else: raise ValueError(f'Unexpected SVG path command {cmd}')
    finish(False)
    return result

def path_shapes(path_id):
    result=[]
    for j,shape in enumerate(parse_path(PATHS[path_id]['d'])):
        result.append({'ty':'sh','nm':f'{path_id} subpath {j+1}','ks':const(shape)})
    return result

def fill(color):
    return {'ty':'fl','nm':'Original logo color','c':const(rgb(color)),
            'o':const(100),'r':1}
def layer(name,shapes,ks,ind):
    return {'ddd':0,'ind':ind,'ty':4,'nm':name,'sr':1,'ks':ks,'ao':0,
            'shapes':shapes,'ip':0,'op':210,'st':0,'bm':0}

layers=[]
def add(name,shapes,ks):
    layers.append(layer(name,shapes,ks,len(layers)+1))

# Layer order is top to bottom. The writing stays above the finished logo.
with Path('make_paw_animation.py').open() as f:
    tree=ast.parse(f.read())
routes=next(ast.literal_eval(node.value) for node in tree.body
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='routes' for t in node.targets))
weights=[]
for pts in routes:
    weights.append(sum(((b[0]-a[0])**2+(b[1]-a[1])**2)**.5 for a,b in zip(pts,pts[1:])) or 12)
total=sum(weights)
elapsed=0
for n,(pts,weight) in enumerate(zip(routes,weights)):
    start=round(107+elapsed/total*85)
    end=round(107+(elapsed+weight)/total*85)
    elapsed+=weight
    vertices=[[x*600/1520,(y+720)*600/1520] for x,y in pts]
    path={'c':False,'v':vertices,'i':[[0,0] for _ in vertices],
          'o':[[0,0] for _ in vertices]}
    shapes=[{'ty':'sh','nm':f'Pen path {n+1}','ks':const(path)},
            {'ty':'st','nm':'Cursive pen','c':const(rgb('#F6A274')),
             'o':const(100),'w':const(8.4),'lc':2,'lj':2,'ml':4},
            {'ty':'tm','nm':'Write stroke','s':const(0),
             'e':keys([(start,0),(end,100)]),'o':const(0),'m':1}]
    add(f'Connection handwritten stroke {n+1}',shapes,
        transform(const([LOGO_X,LOGO_Y,0]),opacity=keys([(0,100),(192,100),(198,0)])))

# The final vector lettering replaces the guide strokes without a visible jump.
for name in ('Vector_8','Vector_9','Vector_10','Vector_11'):
    add('Connection original '+name,
        path_shapes(name)+[fill(PATHS[name]['fill'])],
        transform(const([LOGO_X,LOGO_Y,0]),opacity=keys([(0,0),(190,0),(198,100)])))

for name in ('Vector_6','Vector_7'):
    add('PAW lettering '+name,path_shapes(name)+[fill(PATHS[name]['fill'])],
        transform(const([LOGO_X,LOGO_Y,0]),
                  opacity=keys([(0,0),(55,0),(76,100)])))

for j,name in enumerate(('Vector','Vector_2','Vector_3','Vector_4','Vector_5')):
    begin=(0 if j==0 else round((.46+(j-1)*.19)*FPS))
    end=begin+14 if j==0 else begin+10
    reveal=[(0,0),(end,100)] if j==0 else [(0,0),(begin,0),(end,100)]
    add('Paw '+('heart' if j==0 else f'toe {j}'),
        path_shapes(name)+[fill(PATHS[name]['fill'])],
        transform(keys([(0,[360,340,0]),(50,[360,340,0]),(72,PAW_FINAL)]),
                  anchor=PAW_ANCHOR,
                  scale=keys([(0,[158.5,158.5,100]),(50,[158.5,158.5,100]),(72,[100,100,100])]),
                  rotation=keys([(0,180),(80,180),(98,0)]),
                  opacity=keys(reveal)))

add('Warm background',[{'ty':'rc','nm':'Background','d':1,
                        's':const([720,720]),'p':const([360,360]),'r':const(0)},
                       fill('#FFFAF6')],transform(const([0,0,0])))

anim={'v':'5.12.2','fr':FPS,'ip':0,'op':210,'w':720,'h':720,
      'nm':'Paw Connection intro','ddd':0,'assets':[],'layers':layers,'markers':[]}
OUT.write_text(json.dumps(anim,separators=(',',':')))
print(OUT,OUT.stat().st_size,'bytes',len(layers),'vector layers')
