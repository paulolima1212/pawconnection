from PIL import Image, ImageDraw
import numpy as np
import subprocess, tempfile, os, math
from lxml import etree

ROOT='upload/'
OUT='Paw_Connection_animacao.mp4'
W=720; H=720; FPS=30; DURATION=7.0
BG=(255,250,246,255)

src=Image.open(ROOT+'icon.png').convert('RGBA')
arr=np.array(src)
red=(arr[:,:,0]>210)&(arr[:,:,1]<145)&(arr[:,:,2]<155)&(arr[:,:,3]>0)
orange=(arr[:,:,0]>230)&(arr[:,:,1]>135)&(arr[:,:,1]<205)&(arr[:,:,3]>0)&(~red)

def masked(mask):
    a=arr.copy(); a[:,:,3]=np.where(mask,arr[:,:,3],0)
    return Image.fromarray(a,'RGBA')

heart=masked(red)
toes=[]
for x0,x1,y0,y1 in [(0,290,150,450),(260,555,0,300),(570,875,0,300),(740,1024,260,530)]:
    m=np.zeros(red.shape,bool); m[y0:y1,x0:x1]=orange[y0:y1,x0:x1]
    toes.append(masked(m))

svg=etree.parse(ROOT+'paw-connection-logo.svg')
ns='{http://www.w3.org/2000/svg}'
def render(parts):
    root=etree.fromstring(etree.tostring(svg.getroot()))
    for p in list(root[0]):
        if p.get('id') not in parts: root[0].remove(p)
    with tempfile.NamedTemporaryFile(suffix='.svg') as f, tempfile.NamedTemporaryFile(suffix='.png') as dest:
        f.write(etree.tostring(root)); f.flush()
        subprocess.run(['inkscape',f.name,'--export-filename='+dest.name,'--export-width=760'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        return Image.open(dest.name).convert('RGBA').copy()

letters=render({'Vector_6','Vector_7'})
paw=render({'Vector','Vector_2','Vector_3','Vector_4','Vector_5'})
connection=render({'Vector_8','Vector_9','Vector_10','Vector_11'})

def smooth(a):
    a=max(0,min(1,a)); return a*a*(3-2*a)

def place(frame, layer, cx, cy, width, opacity=1, angle=0):
    if opacity<=0: return
    height=round(width*layer.height/layer.width)
    im=layer.resize((round(width),height),Image.Resampling.LANCZOS)
    if angle: im=im.rotate(angle,Image.Resampling.BICUBIC,expand=True)
    if opacity<1: im.putalpha(im.getchannel('A').point(lambda a:int(a*opacity)))
    frame.alpha_composite(im,(round(cx-im.width/2),round(cy-im.height/2)))

# The finished brand is exactly the supplied vector, centred on a warm neutral field.
logo_width=600
logo_cx=360; logo_cy=360
logo_x=logo_cx-logo_width/2
logo_y=logo_cy-(logo_width*letters.height/letters.width)/2
final_paw_cx=logo_x+logo_width*81.5/190
final_paw_cy=logo_y+logo_width*45.8/190

# Pen routes follow the actual cursive lettering, including the loops and pen lifts.
# Coordinates refer to the 1520-pixel preview of the supplied vector artwork.
routes=[
 [(144,60),(128,43),(102,41),(75,48),(55,69),(43,94),(42,127),(48,155),(65,178),(91,190),(125,188),(152,173),(175,139)], # C
 [(175,139),(190,111),(217,102),(241,107),(261,127),(269,151),(260,173),(241,188),(214,188),(190,177),(177,155)], # o
 [(319,110),(320,151),(326,181),(339,184),(349,146),(360,119),(374,110),(390,125),(405,154),(423,179),(440,184),(461,171),(485,140),(506,119)], # n
 [(538,111),(538,150),(543,181),(556,184),(565,143),(576,117),(589,112),(606,130),(625,166),(645,184),(660,176),(682,152)], # n
 [(682,152),(696,122),(720,108),(742,111),(753,125),(739,141),(705,145),(687,146),(693,172),(717,188),(746,187),(773,171),(798,140)], # e
 [(798,140),(813,113),(835,105),(859,108),(879,120),(861,112),(833,115),(811,133),(800,157),(815,181),(845,190),(871,180),(895,149)], # c
 [(966,30),(948,57),(939,96),(934,132),(941,164),(960,182),(984,185),(1010,173),(1031,150)], # t
 [(911,62),(944,72),(977,73),(1010,73),(1035,66)], # t cross
 [(1089,109),(1078,132),(1073,159),(1082,182),(1102,185),(1125,168),(1150,139)], # i
 [(1098,55)], # i dot
 [(1150,139),(1166,113),(1190,104),(1219,111),(1246,132),(1252,153),(1241,177),(1218,188),(1193,187),(1170,170),(1156,146)], # o
 [(1314,109),(1314,154),(1321,184),(1336,180),(1344,140),(1355,115),(1370,114),(1389,143),(1410,176),(1431,184),(1454,169),(1480,144)] # n
]
def pen_route(points):
    pts=[(x/2,(y+720)/2) for x,y in points]
    dense=[]
    for a,b in zip(pts,pts[1:]):
        length=math.dist(a,b)
        count=max(2,int(length/1.5))
        dense += [(a[0]+(b[0]-a[0])*j/count,a[1]+(b[1]-a[1])*j/count) for j in range(count)]
    return dense+[pts[-1]]
pen_paths=[pen_route(points) for points in routes]
pen_weights=[len(p) for p in pen_paths]
pen_total=sum(pen_weights)
letter_ends=[175,300,530,680,790,910,1050,1050,1140,1140,1290,1520]

def connection_progress(progress):
    if progress>=1: return connection
    mask=Image.new('L',connection.size)
    draw=ImageDraw.Draw(mask)
    steps=progress*pen_total
    prior_end=0
    for path,weight,end in zip(pen_paths,pen_weights,letter_ends):
        count=max(0,min(weight,int(steps)))
        if steps>=weight:
            draw.rectangle((prior_end/2,360,end/2,480),fill=255)
        if count:
            draw.line(path[:count],fill=255,width=22,joint='curve')
            x,y=path[count-1]
            draw.ellipse((x-11,y-11,x+11,y+11),fill=255)
        steps-=weight
        prior_end=end
    im=connection.copy()
    a=np.asarray(im.getchannel('A')).astype(np.uint16)
    m=np.asarray(mask).astype(np.uint16)
    im.putalpha(Image.fromarray((a*m//255).astype('uint8')))
    return im

def frame_at(t):
    f=Image.new('RGBA',(W,H),BG)
    shrink=smooth((t-1.65)/.75)
    icon_width=390+(246-390)*shrink
    cx=360+(final_paw_cx-360)*shrink
    cy=340+(final_paw_cy-340)*shrink
    finish=smooth((t-3.25)/.26)
    visible=1-finish
    spin=180*smooth((t-2.68)/.58)
    place(f,heart,cx,cy,icon_width,smooth(t/.48)*visible,spin)
    for j,toe in enumerate(toes):
        a=smooth((t-(.46+j*.19))/.34)*visible
        place(f,toe,cx,cy,icon_width,a,spin)
    place(f,letters,logo_cx,logo_cy,logo_width,smooth((t-1.85)/.65))
    place(f,paw,logo_cx,logo_cy,logo_width,finish)
    progress=max(0,min(1,(t-3.55)/2.85))
    if progress: place(f,connection_progress(progress),logo_cx,logo_cy,logo_width)
    return f.convert('RGB')

proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',OUT],stdin=subprocess.PIPE)
for i in range(round(DURATION*FPS)):
    proc.stdin.write(frame_at(i/FPS).tobytes())
proc.stdin.close()
if proc.wait(): raise RuntimeError('ffmpeg failed')

frames=[frame_at(i/15).resize((480,480),Image.Resampling.LANCZOS).convert('P',palette=Image.Palette.ADAPTIVE) for i in range(round(DURATION*15))]
frames[0].save('Paw_Connection_animacao.gif',save_all=True,append_images=frames[1:],duration=67,loop=0,optimize=True)
