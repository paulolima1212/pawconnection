# Paw Connection: animação Lottie

## Arquivos para o app

Coloque `paw-connection-intro.lottie.json` e `PawConnectionIntro.tsx` na mesma pasta do projeto React Native. O componente reproduz a animação uma vez e chama `onFinish` ao terminar.

Instale uma versão de `lottie-react-native` compatível com a versão de React Native do projeto. Em um projeto Expo, use `npx expo install lottie-react-native`; em React Native sem Expo, consulte a matriz de compatibilidade e instale a versão correspondente. Depois, gere novamente o aplicativo Android: adicionar uma biblioteca nativa exige novo build.

Exemplo:

```tsx
import { PawConnectionIntro } from './PawConnectionIntro';

export function IntroScreen({ onComplete }: { onComplete: () => void }) {
  return <PawConnectionIntro onFinish={onComplete} />;
}
```

O JSON é um arquivo comum: `require('./paw-connection-intro.lottie.json')` passa pelo Metro sem adicionar uma extensão de asset. Esta sequência de 7 segundos deve rodar em uma tela do aplicativo depois da splash screen nativa do Android.

## Fonte da animação

`build_lottie.py` gera o JSON a partir de `upload/paw-connection-logo.svg` e dos caminhos de escrita definidos em `make_paw_animation.py`. O arquivo `icon.png` e o SVG originais estão incluídos neste pacote. Execute `python build_lottie.py` na raiz do pacote para recriar o JSON. A animação Lottie usa somente vetores, sem quadros rasterizados do vídeo.

## Verificação

O JSON foi validado estruturalmente; a geometria final foi comparada com o SVG original e coincidiu pixel a pixel em uma renderização independente. A reprodução no Android ainda depende de teste dentro do projeto, pois o aplicativo e a versão de React Native não foram fornecidos.
